<?php 
/* 
  Promo Box Remover for Plesk 11.5
  by Jay Versluis
  http://wpguru.co.uk
  */
  ?>
<div id="page">
<div id="wrapper">
<div id="content-wrapper">
<div id="content">
<div id="content-body">
<div id="main">


<p>This Extension was brought to you by</p>
<p><img src="guru-header-2014.png"></p>

<p><a href="http://wpguru.co.uk/2014/02/how-to-create-an-extension-in-plesk/" target="_blank">Extension Demo by Jay Versluis</a> | <a href="http://ext.plesk.com" target="_blank">more about Plesk Extensions</a> | <a href="http://wphosting.tv" target="_blank">WP Hosting</a></p>

<p><span><!-- Social Buttons -->

<!-- Google+ -->
<div class="g-follow" data-annotation="bubble" data-height="20" data-href="//plus.google.com/116464794189222694062" data-rel="author"></div>

<!-- Place this tag after the last widget tag. -->
<script type="text/javascript">
  (function() {
    var po = document.createElement('script'); po.type = 'text/javascript'; po.async = true;
    po.src = 'https://apis.google.com/js/platform.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(po, s);
  })();
</script>

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

<!-- Twitter -->
<a href="https://twitter.com/versluis" class="twitter-follow-button" data-show-count="true">Follow @versluis</a>
<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?'http':'https';if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+'://platform.twitter.com/widgets.js';fjs.parentNode.insertBefore(js,fjs);}}(document, 'script', 'twitter-wjs');</script>

<!-- Facebook -->
<iframe src="//www.facebook.com/plugins/like.php?href=https%3A%2F%2Fwww.facebook.com%2Fpages%2FThe-WP-Guru%2F162188713810370&amp;width&amp;layout=button_count&amp;action=like&amp;show_faces=true&amp;share=true&amp;height=21&amp;appId=186277158097599" scrolling="no" frameborder="0" style="border:none; overflow:hidden; height:21px;" allowTransparency="true"></iframe>

</span></p>
</div></div></div></div></div></div>

